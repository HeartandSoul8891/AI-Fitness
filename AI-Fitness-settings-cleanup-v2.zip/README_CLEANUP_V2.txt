AI-Fitness settings cleanup v2

This package replaces the affected tab files with the corrected versions.

What is fixed:
- Settings file is the source of truth for datasets/output/model directories.
- Removed per-tab dataset/model path selectors from BBox and pseudo-SEGM auto-taggers.
- Removed directory/settings panels from Pose, OBB, Depth, Classification, and Semantic Segmentation.
- Removed ./raw_images and datasets/test_images fallbacks.
- Zero-Shot now uses Settings -> datasets_folder and reports how many image files it actually finds.
- Heavy tagger/ML modules are imported inside the tab function, not at module import time.
- Classification/segmentation/pose/OBB/depth annotation controls remain part of their actual tagging workflow.

Important:
- BBox and pseudo-SEGM use the first model file found (sorted) in the configured ultralytics_bbox_folder because there is intentionally no model dropdown.
- main.py was intentionally not changed.
- Existing project-root manifest filenames are preserved.
